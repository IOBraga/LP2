﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[8];
            int[] letras = new int[8];

            for (int i = 0; i < 8; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome " + (i + 1) + ":",
                    "Entrada dos Nomes");

                letras[i] = nomes[i].Replace(" ", "").Length;

                lbxNomes.Items.Add("O nome: " + nomes[i] + " tem " + letras[i] + " caracteres" + "\n");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxNomes.Items.Clear();
        }
    }
}
