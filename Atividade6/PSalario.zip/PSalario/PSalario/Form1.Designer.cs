﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumFunc = new System.Windows.Forms.Label();
            this.lblSalBru = new System.Windows.Forms.Label();
            this.lblNumFilho = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRFF = new System.Windows.Forms.Label();
            this.lblSalLiqui = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblDesctINSS = new System.Windows.Forms.Label();
            this.lblDescontIRFF = new System.Windows.Forms.Label();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.btnValDescont = new System.Windows.Forms.Button();
            this.nudNumFilho = new System.Windows.Forms.NumericUpDown();
            this.rbtnMasc = new System.Windows.Forms.RadioButton();
            this.rbtnFem = new System.Windows.Forms.RadioButton();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtbxAliqIRFF = new System.Windows.Forms.TextBox();
            this.txtSalLiqui = new System.Windows.Forms.TextBox();
            this.txtDescontINSS = new System.Windows.Forms.TextBox();
            this.txtDescontIRFF = new System.Windows.Forms.TextBox();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.txtSalBruto = new System.Windows.Forms.TextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumFilho)).BeginInit();
            this.gbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNumFunc
            // 
            this.lblNumFunc.AutoSize = true;
            this.lblNumFunc.Location = new System.Drawing.Point(20, 30);
            this.lblNumFunc.Name = "lblNumFunc";
            this.lblNumFunc.Size = new System.Drawing.Size(90, 13);
            this.lblNumFunc.TabIndex = 0;
            this.lblNumFunc.Text = "Nome funcionário";
            // 
            // lblSalBru
            // 
            this.lblSalBru.AutoSize = true;
            this.lblSalBru.Location = new System.Drawing.Point(20, 79);
            this.lblSalBru.Name = "lblSalBru";
            this.lblSalBru.Size = new System.Drawing.Size(67, 13);
            this.lblSalBru.TabIndex = 1;
            this.lblSalBru.Text = "Salário Bruto";
            // 
            // lblNumFilho
            // 
            this.lblNumFilho.AutoSize = true;
            this.lblNumFilho.Location = new System.Drawing.Point(20, 125);
            this.lblNumFilho.Name = "lblNumFilho";
            this.lblNumFilho.Size = new System.Drawing.Size(86, 13);
            this.lblNumFilho.TabIndex = 2;
            this.lblNumFilho.Text = "Número de filhos";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(29, 273);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(75, 13);
            this.lblAliqINSS.TabIndex = 3;
            this.lblAliqINSS.Text = "Alíquota INSS";
            // 
            // lblAliqIRFF
            // 
            this.lblAliqIRFF.AutoSize = true;
            this.lblAliqIRFF.Location = new System.Drawing.Point(29, 309);
            this.lblAliqIRFF.Name = "lblAliqIRFF";
            this.lblAliqIRFF.Size = new System.Drawing.Size(73, 13);
            this.lblAliqIRFF.TabIndex = 4;
            this.lblAliqIRFF.Text = "Alíquota IRFF";
            // 
            // lblSalLiqui
            // 
            this.lblSalLiqui.AutoSize = true;
            this.lblSalLiqui.Location = new System.Drawing.Point(25, 388);
            this.lblSalLiqui.Name = "lblSalLiqui";
            this.lblSalLiqui.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiqui.TabIndex = 5;
            this.lblSalLiqui.Text = "Salário Líquido";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(25, 350);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalFamilia.TabIndex = 6;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblDesctINSS
            // 
            this.lblDesctINSS.AutoSize = true;
            this.lblDesctINSS.Location = new System.Drawing.Point(353, 309);
            this.lblDesctINSS.Name = "lblDesctINSS";
            this.lblDesctINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDesctINSS.TabIndex = 8;
            this.lblDesctINSS.Text = "Desconto INSS";
            // 
            // lblDescontIRFF
            // 
            this.lblDescontIRFF.AutoSize = true;
            this.lblDescontIRFF.Location = new System.Drawing.Point(353, 346);
            this.lblDescontIRFF.Name = "lblDescontIRFF";
            this.lblDescontIRFF.Size = new System.Drawing.Size(79, 13);
            this.lblDescontIRFF.TabIndex = 9;
            this.lblDescontIRFF.Text = "Desconto IRFF";
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(116, 23);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(160, 20);
            this.txtNomeFunc.TabIndex = 11;
            // 
            // btnValDescont
            // 
            this.btnValDescont.Location = new System.Drawing.Point(300, 218);
            this.btnValDescont.Name = "btnValDescont";
            this.btnValDescont.Size = new System.Drawing.Size(132, 25);
            this.btnValDescont.TabIndex = 14;
            this.btnValDescont.Text = "Verificar Desconto";
            this.btnValDescont.UseVisualStyleBackColor = true;
            this.btnValDescont.Click += new System.EventHandler(this.BtnValDescont_Click);
            // 
            // nudNumFilho
            // 
            this.nudNumFilho.Location = new System.Drawing.Point(116, 123);
            this.nudNumFilho.Name = "nudNumFilho";
            this.nudNumFilho.Size = new System.Drawing.Size(160, 20);
            this.nudNumFilho.TabIndex = 15;
            // 
            // rbtnMasc
            // 
            this.rbtnMasc.AutoSize = true;
            this.rbtnMasc.Location = new System.Drawing.Point(67, 39);
            this.rbtnMasc.Name = "rbtnMasc";
            this.rbtnMasc.Size = new System.Drawing.Size(34, 17);
            this.rbtnMasc.TabIndex = 17;
            this.rbtnMasc.TabStop = true;
            this.rbtnMasc.Text = "M";
            this.rbtnMasc.UseVisualStyleBackColor = true;
            // 
            // rbtnFem
            // 
            this.rbtnFem.AutoSize = true;
            this.rbtnFem.Location = new System.Drawing.Point(67, 82);
            this.rbtnFem.Name = "rbtnFem";
            this.rbtnFem.Size = new System.Drawing.Size(31, 17);
            this.rbtnFem.TabIndex = 18;
            this.rbtnFem.TabStop = true;
            this.rbtnFem.Text = "F";
            this.rbtnFem.UseVisualStyleBackColor = true;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnMasc);
            this.gbxSexo.Controls.Add(this.rbtnFem);
            this.gbxSexo.Location = new System.Drawing.Point(432, 23);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(173, 120);
            this.gbxSexo.TabIndex = 19;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Location = new System.Drawing.Point(121, 266);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(160, 20);
            this.txtAliqINSS.TabIndex = 21;
            // 
            // txtbxAliqIRFF
            // 
            this.txtbxAliqIRFF.Location = new System.Drawing.Point(121, 302);
            this.txtbxAliqIRFF.Name = "txtbxAliqIRFF";
            this.txtbxAliqIRFF.Size = new System.Drawing.Size(160, 20);
            this.txtbxAliqIRFF.TabIndex = 22;
            // 
            // txtSalLiqui
            // 
            this.txtSalLiqui.Location = new System.Drawing.Point(121, 388);
            this.txtSalLiqui.Name = "txtSalLiqui";
            this.txtSalLiqui.Size = new System.Drawing.Size(160, 20);
            this.txtSalLiqui.TabIndex = 24;
            // 
            // txtDescontINSS
            // 
            this.txtDescontINSS.Location = new System.Drawing.Point(445, 306);
            this.txtDescontINSS.Name = "txtDescontINSS";
            this.txtDescontINSS.Size = new System.Drawing.Size(160, 20);
            this.txtDescontINSS.TabIndex = 25;
            // 
            // txtDescontIRFF
            // 
            this.txtDescontIRFF.Location = new System.Drawing.Point(445, 343);
            this.txtDescontIRFF.Name = "txtDescontIRFF";
            this.txtDescontIRFF.Size = new System.Drawing.Size(160, 20);
            this.txtDescontIRFF.TabIndex = 26;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(432, 149);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(62, 17);
            this.ckbxCasado.TabIndex = 27;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Location = new System.Drawing.Point(116, 76);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(160, 20);
            this.txtSalBruto.TabIndex = 28;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Location = new System.Drawing.Point(121, 347);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.Size = new System.Drawing.Size(160, 20);
            this.txtSalarioFamilia.TabIndex = 29;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(348, 388);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(125, 23);
            this.btnClear.TabIndex = 30;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnResetar_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(499, 388);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(125, 23);
            this.btnClose.TabIndex = 31;
            this.btnClose.Text = "Sair";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(74, 190);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(36, 13);
            this.lblDados.TabIndex = 32;
            this.lblDados.Text = "dados";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 423);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtSalarioFamilia);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.txtDescontIRFF);
            this.Controls.Add(this.txtDescontINSS);
            this.Controls.Add(this.txtSalLiqui);
            this.Controls.Add(this.txtbxAliqIRFF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.nudNumFilho);
            this.Controls.Add(this.btnValDescont);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.lblDescontIRFF);
            this.Controls.Add(this.lblDesctINSS);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblSalLiqui);
            this.Controls.Add(this.lblAliqIRFF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblNumFilho);
            this.Controls.Add(this.lblSalBru);
            this.Controls.Add(this.lblNumFunc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudNumFilho)).EndInit();
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumFunc;
        private System.Windows.Forms.Label lblSalBru;
        private System.Windows.Forms.Label lblNumFilho;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRFF;
        private System.Windows.Forms.Label lblSalLiqui;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblDesctINSS;
        private System.Windows.Forms.Label lblDescontIRFF;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.Button btnValDescont;
        private System.Windows.Forms.NumericUpDown nudNumFilho;
        private System.Windows.Forms.RadioButton rbtnMasc;
        private System.Windows.Forms.RadioButton rbtnFem;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtbxAliqIRFF;
        private System.Windows.Forms.TextBox txtSalLiqui;
        private System.Windows.Forms.TextBox txtDescontINSS;
        private System.Windows.Forms.TextBox txtDescontIRFF;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.TextBox txtSalBruto;
        private System.Windows.Forms.TextBox txtSalarioFamilia;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblDados;
    }
}

