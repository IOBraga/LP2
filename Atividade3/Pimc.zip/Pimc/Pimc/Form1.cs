﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            //Fecha a Aplicação
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //Limpa os dados e volta ao primeiro campo
            txtAltura.Clear();
            txtPeso.Clear();
            txtImc.Clear();
            txtPeso.Focus();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Double altura, peso, imc;

            //Conversão de Text para Double
            if (Double.TryParse(txtAltura.Text, out altura) &&
               Double.TryParse(txtPeso.Text, out peso))
            {
                //Valida se a altura é maior que 0
                if (altura <= 0)
                {
                    MessageBox.Show("A altura não pode ser menor ou igual a 0");
                    txtAltura.Clear();
                    txtAltura.Focus();
                }
                else
                {
                    //Faz o cálculo do Imc
                    imc = peso / Math.Pow(altura, 2);
                    imc = Math.Round(imc, 1);
                    txtImc.Text = imc.ToString("N2");

                    //Testa para ver em qual categoria o imc se encaixa
                    if (imc < 18.5)
                    {
                        MessageBox.Show("Magreza");
                    }
                    else
                    {
                        if (imc <= 24.9)
                        {
                            MessageBox.Show("Normal");
                        }
                        else
                        {
                            if (imc <= 29.9)
                            {
                                MessageBox.Show("Sobrepeso");
                            }
                            else
                            {
                                if (imc <= 39.9)
                                {
                                    MessageBox.Show("Obesidade");
                                }
                                else
                                {
                                    MessageBox.Show("Obesidade Grave");
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                //Caso os valores sejam inválidos
                MessageBox.Show("Valores Inválidos");
                txtPeso.Clear();
                txtAltura.Clear();
                txtAltura.Focus();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
