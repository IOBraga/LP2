﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Faz o carregamento da Tela
        }

        //Fecha a aplicação
        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            //Limpa os dados
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
            //Volta para o primeiro campo
            txtNumero1.Focus();
        }

        //Soma
        private void BtnSoma_Click(object sender, EventArgs e)
        {
            Double num1, num2, resultado;

            //TryParse faz a conversão de Text para Double
            if (Double.TryParse(txtNumero1.Text, out num1) &&
            Double.TryParse(txtNumero2.Text, out num2))
            {
                resultado = num1 + num2;

                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                //Caso usuário não coloque valores
                MessageBox.Show("Insira Valores!");
                txtNumero1.Focus();
            }
        }

        //Subtração
        private void BtnSubtracao_Click(object sender, EventArgs e)
        {
            Double num1, num2, resultado;

            //TryParse faz a conversão de Text para Double
            if (Double.TryParse(txtNumero1.Text, out num1) &&
            Double.TryParse(txtNumero2.Text, out num2))
            {
                resultado = num1 - num2;

                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                //Caso usuário não coloque valores
                MessageBox.Show("Insira Valores!");
                txtNumero1.Focus();
            }
        }

        //Multiplicação
        private void BtnMult_Click(object sender, EventArgs e)
        {
            Double num1, num2, resultado;

            //TryParse faz a conversão de Text para Double
            if (Double.TryParse(txtNumero1.Text, out num1) &&
            Double.TryParse(txtNumero2.Text, out num2))
            {
                resultado = num1 * num2;

                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                //Caso usuário não coloque valores
                MessageBox.Show("Insira Valores!");
                txtNumero1.Focus();
            }
        }

        //Divisão
        private void BtnDiv_Click(object sender, EventArgs e)
        {
            Double num1, num2, resultado;

                //TryParse faz a conversão de Text para Double
                if (Double.TryParse(txtNumero1.Text, out num1) &&
                Double.TryParse(txtNumero2.Text, out num2))
                {
                    if(num2 != 0)
                {
                    resultado = num1 / num2;

                    txtResultado.Text = resultado.ToString("N2");
                }
                else
                {
                    MessageBox.Show("Não existe divisão por 0!");
                    txtNumero1.Clear();
                    txtNumero2.Clear();
                    txtNumero1.Focus();
                }
                }
                else
                {
                    MessageBox.Show("Insira Valores!");
                    txtNumero1.Focus();
           }
        }

        private void TxtNumero1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");

                e.Handled = true;
            }
        }
    }
 }
