﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] vendas = new string[3, 4];
            double semana;
            double totalGeral = 0;
            double[,] vendasMes = new double[3 ,4];
            string saida = "";
            double totalMes = 0;

            for (var i = 0; i < 3; i++)
            {
                totalMes = 0;

                for (var j = 0; j < 4; j++)
                {
                    vendas[i, j] = Interaction.InputBox("Digite o total das vendas da semana " + (j + 1) 
                    + " do mes " + (i + 1), "Entrada dos valores");

                    if(!double.TryParse(vendas[i, j], out vendasMes[i, j]))
                    {
                        MessageBox.Show("Digite valores válidos");
                        j--;
                    }
                    else
                    {
                        totalMes += vendasMes[i, j];
                        totalGeral += totalMes;
                    }
                }
            }

            for (var i = 0; i < 3; i++)
                for (var j = 0; j < 4; j++)
                {
                    lbxVendas.Items.Add("O total do mês" + (i + 1) + "  Semana " + (j + 1) + ":" + vendas[i, j] + "\n"
                        + "\n");
                }
            lbxVendas.Items.Add("Total Geral: " + totalGeral);
        }
    }
}
