﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Fecha a aplicação
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Limpa os dados das caixas de texto
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //Formas de limpar dados, todos são válidos
            txtAltura.Clear(); // mais fácil de lembrar
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;

            txtRaio.Focus(); //Volta para o primeiro componente
        }

        //Método que faz o cálculo do Raio
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Double volume, raio, altura;

            //TryParse faz a conversão de Text para Double
            if(Double.TryParse(txtAltura.Text, out altura) &&
            Double.TryParse(txtRaio.Text, out raio))
            {
                //Comparação dos dados, If encadeado
                if ((altura <= 0) || (raio <= 0))
                {
                    MessageBox.Show("Altura e Raio devem ser maiores do que zero");
                    //Volta para o textbox do Raio, campo principal
                    txtRaio.Focus();
                }
                
                //Se cair no else, ele faz o cálculo
                else
                {
                  //volume = 3.14 * raio * raio * altura;
                    volume = Math.PI * Math.Pow(raio, 2) * altura;

                  //Variável volume recebe ela mesmo transformada em String
                    txtVolume.Text = volume.ToString("N2");
                }
            }

            //Caso os valores inseridos lá no início forem vazios
            else
            {
                MessageBox.Show("Valores inválidos");
                txtRaio.Focus();
            }
        }
    }
}
