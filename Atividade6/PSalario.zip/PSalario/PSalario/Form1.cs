﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnValDescont_Click(object sender, EventArgs e)
        {
            //Variáveis
            double salBruto = 0, descontoINSS = 0, descontoIRFF = 0,
                   salFamilia = 0, salLiqui = 0, numFilhos = 0;

            // Testa nome vazio
            if (txtNomeFunc.Text == String.Empty)
            { 
                MessageBox.Show("O nome do funcionário" +
                "\nnão pode ser vazio!");
                txtSalBruto.Clear();
                txtNomeFunc.Focus();
            }

            //Convert os textos para double
            if (double.TryParse(txtSalBruto.Text, out salBruto)
                && double.TryParse(nudNumFilho.Text, out numFilhos))
            {
                if (salBruto == 0)
                {
                    MessageBox.Show("O salário precisa ser " +
                    "\n maior que zero!");
                }

                //Desconto INSS
                else if (salBruto <= 800.47)
                {
                    descontoINSS = 0.0765 * salBruto;
                    txtDescontINSS.Text = "R$ " + descontoINSS.ToString("N2");
                    txtAliqINSS.Text = "7.65%";
                }

                else if (salBruto <= 1050)
                {
                    descontoINSS = 0.0865 * salBruto;
                    txtDescontINSS.Text = "R$ " + descontoINSS.ToString("N2");
                    txtAliqINSS.Text = "8.65%";
                }

                else if (salBruto <= 1400.77)
                {
                    descontoINSS = 0.09 * salBruto;
                    txtDescontINSS.Text = "R$ " + descontoINSS.ToString("N2");
                    txtAliqINSS.Text = "9.00%";
                }

                else if (salBruto <= 2801.56)
                {
                    descontoINSS = 0.11 * salBruto;
                    txtDescontINSS.Text = "R$ " + descontoINSS.ToString("N2");
                    txtAliqINSS.Text = "11.00%";
                }
                else
                {
                    descontoINSS = 308.17;
                    txtDescontINSS.Text = "R$ " + descontoINSS.ToString("N2");
                    txtAliqINSS.Text = "308.17 (Teto)";
                }

                //Desconto IRFF
                if (salBruto <= 1257.12)
                {
                    descontoIRFF = 0;
                    txtDescontIRFF.Text = "R$ " + descontoIRFF.ToString("N2");
                    txtbxAliqIRFF.Text = "Isento";
                }

                else if (salBruto <= 2512.08)
                {
                    descontoIRFF = 0.15 * salBruto;
                    txtDescontIRFF.Text = "R$ " + descontoIRFF.ToString("N2");
                    txtbxAliqIRFF.Text = "15.00%";
                }

                else
                {
                    descontoIRFF = 0.275 * salBruto;
                    txtDescontIRFF.Text = "R$ " + descontoIRFF.ToString("N2");
                    txtbxAliqIRFF.Text = "27.5%";
                }

                //Salário Família
                if (numFilhos > 0)
                {
                    if (salBruto <= 435.52)
                    {
                        salFamilia = (22.33 * numFilhos);
                        txtSalarioFamilia.Text = salFamilia.ToString("N2");
                    }

                    else if (salBruto <= 645.61)
                    {
                        salFamilia = (15.74 * numFilhos);
                        txtSalarioFamilia.Text = salFamilia.ToString("N2");
                    }

                    else
                        salFamilia = 0;
                        txtSalarioFamilia.Text = salFamilia.ToString();
                }

                //Salário Líquido
                if (salFamilia > 0)
                {
                    salLiqui = salBruto - (descontoINSS + descontoIRFF) + salFamilia;
                    txtSalLiqui.Text = salLiqui.ToString("N2");
                }

                else
                    salLiqui = salBruto - (descontoINSS + descontoIRFF);
                    txtSalLiqui.Text = salLiqui.ToString("N2");

                //Mensagem
                if (txtNomeFunc.Text == String.Empty)
                {
                    lblDados.Text = "Dados";
                }

                else
                {
                    lblDados.Text = "Os descontos do salário " +
                        (rbtnFem.Checked ? " da Sra " : " do Sr ") + txtNomeFunc.Text +
                        " que é "
                        + (ckbxCasado.Checked ? " casado" : "solteiro") + " e tem "
                        + numFilhos + " filhos";
                }
            }

            else
            {
                MessageBox.Show("Insira um salário válido!" + "\nNão pode ser 0");
                txtNomeFunc.Clear();
                ckbxCasado.Checked = false;
                rbtnFem.Checked = false;
                rbtnMasc.Checked = false;
                nudNumFilho.Text = "0";
                txtNomeFunc.Focus();
            }
        }

        //Reseta a tela
        private void BtnResetar_Click(object sender, EventArgs e)
        {
            txtNomeFunc.Clear();
            txtSalBruto.Clear();
            nudNumFilho.Text = "0";
            txtDescontINSS.Clear();
            txtDescontIRFF.Clear();
            txtAliqINSS.Clear();
            txtbxAliqIRFF.Clear();
            txtSalarioFamilia.Clear();
            txtSalLiqui.Clear();
            ckbxCasado.Checked = false;
            rbtnFem.Checked = false;
            rbtnMasc.Checked = false;
            lblDados.ResetText();
            //Volta ao primeiro campo
            txtNomeFunc.Focus();
        }

        //Fecha aplicação
        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
