﻿namespace Pmetodos
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAlfabetico = new System.Windows.Forms.Button();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnNumericos = new System.Windows.Forms.Button();
            this.rtxtTexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnAlfabetico
            // 
            this.btnAlfabetico.Font = new System.Drawing.Font("Arial", 10F);
            this.btnAlfabetico.Location = new System.Drawing.Point(396, 252);
            this.btnAlfabetico.Name = "btnAlfabetico";
            this.btnAlfabetico.Size = new System.Drawing.Size(118, 56);
            this.btnAlfabetico.TabIndex = 20;
            this.btnAlfabetico.Text = "Alfabético";
            this.btnAlfabetico.UseVisualStyleBackColor = true;
            this.btnAlfabetico.Click += new System.EventHandler(this.BtnAlfabetico_Click);
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Font = new System.Drawing.Font("Arial", 10F);
            this.btnEspacoBranco.Location = new System.Drawing.Point(218, 252);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(125, 56);
            this.btnEspacoBranco.TabIndex = 19;
            this.btnEspacoBranco.Text = "Espaços em Branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.BtnEspacoBranco_Click);
            // 
            // btnNumericos
            // 
            this.btnNumericos.Font = new System.Drawing.Font("Arial", 10F);
            this.btnNumericos.Location = new System.Drawing.Point(47, 252);
            this.btnNumericos.Name = "btnNumericos";
            this.btnNumericos.Size = new System.Drawing.Size(125, 56);
            this.btnNumericos.TabIndex = 18;
            this.btnNumericos.Text = "Numéricos";
            this.btnNumericos.UseVisualStyleBackColor = true;
            this.btnNumericos.Click += new System.EventHandler(this.BtnNumericos_Click);
            // 
            // rtxtTexto
            // 
            this.rtxtTexto.Location = new System.Drawing.Point(82, 70);
            this.rtxtTexto.Name = "rtxtTexto";
            this.rtxtTexto.Size = new System.Drawing.Size(390, 133);
            this.rtxtTexto.TabIndex = 21;
            this.rtxtTexto.Text = "";
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 410);
            this.Controls.Add(this.rtxtTexto);
            this.Controls.Add(this.btnAlfabetico);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.btnNumericos);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAlfabetico;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnNumericos;
        private System.Windows.Forms.RichTextBox rtxtTexto;
    }
}